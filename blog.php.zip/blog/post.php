<?php

include_once("teamplates/header.php");

if (isset($_GET['id'])) {
    $postId = $_GET['id'];
    $currentPost;

    foreach ($posts as $post) {
        if ($post['id'] == $postId) {
            $currentPost = $post;
        }
    }
}


?>
<main id="post-container">
    <div class="content-container">
        <h1 id="main-title"><?= $currentPost['title'] ?></h1>
        <p id="post-description"></p>
        <?= $currentPost['description'] ?>
        <div class="img-container">
            <img src="<?= $BASE_URL ?>/img/<?= $currentPost['img'] ?>">
         </div>
         <p class="post-content">jlr fdwtuitg89</p>
        </div>
</main>
<h1><?= $currentPost['title'] ?></h1>
<?php
include_once("teamplates/footer.php");
?>