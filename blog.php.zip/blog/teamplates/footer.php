<?php

    include_once("teamplates/header.php")
?>
<footer><p>Desenvoivido por BelinDEV<p></footer>
<?php

    include_once("teamplates/footer.php")
?>
</body>
</html>