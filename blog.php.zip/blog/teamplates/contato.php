<?php

    include_once("teamplates/header.php")
    

?>
<h1>Pagina de Contato</h1>
<?php

    include_once("teamplates/footer.php")
?>
